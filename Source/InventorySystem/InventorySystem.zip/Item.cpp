// Fill out your copyright notice in the Description page of Project Settings.


#include "Item.h"

FString UItem::GetOtherInformation() {

	return "no other information";
}